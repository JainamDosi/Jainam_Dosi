
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 w-full z-[100] px-8 py-6 flex justify-between items-center mix-blend-difference">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 relative flex items-center justify-center">
            <div className="absolute inset-0 border border-white/40 rounded-full animate-[spin_10s_linear_infinite]"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
        </div>
        <span className="text-xl font-medium tracking-tight">Radika</span>
      </div>

      <nav className="hidden md:flex items-center gap-8 text-sm font-light text-white/70">
        <a href="#" className="hover:text-white transition-colors flex items-center gap-1.5">
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Manifesto
        </a>
        <a href="#" className="hover:text-white transition-colors">Careers</a>
        <a href="#" className="hover:text-white transition-colors">Log in</a>
        <button className="px-6 py-2 bg-white text-black rounded-full font-medium hover:bg-white/90 transition-colors">Sign up</button>
      </nav>

      <button className="flex items-center gap-2 px-4 py-1.5 bg-white/10 backdrop-blur-md border border-white/20 rounded-lg text-sm group">
        <span>Menu</span>
        <div className="flex flex-col gap-1">
            <div className="w-4 h-0.5 bg-white"></div>
            <div className="w-2 h-0.5 bg-white self-end transition-all group-hover:w-4"></div>
        </div>
      </button>
    </header>
  );
};

export default Header;
