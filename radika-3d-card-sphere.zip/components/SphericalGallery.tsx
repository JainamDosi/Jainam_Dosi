
import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { CARD_LIST } from '../constants';

const SphericalGallery: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef({ y: 0 });
  
  // UI State for the slider handle position
  const [sliderVal, setSliderVal] = useState(0.5);
  // Ref for the 3D loop to read without re-triggering useEffect
  const rotationRef = useRef(0.5);
  
  const targetRotationY = useRef(0);
  const currentRotationY = useRef(0);

  // Helper to create a rounded rectangle shape
  const createRoundedRectShape = (width: number, height: number, radius: number) => {
    const shape = new THREE.Shape();
    const x = -width / 2;
    const y = -height / 2;
    shape.moveTo(x + radius, y);
    shape.lineTo(x + width - radius, y);
    shape.quadraticCurveTo(x + width, y, x + width, y + radius);
    shape.lineTo(x + width, y + height - radius);
    shape.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    shape.lineTo(x + radius, y + height);
    shape.quadraticCurveTo(x, y + height, x, y + height - radius);
    shape.lineTo(x, y + radius);
    shape.quadraticCurveTo(x, y, x + radius, y);
    return shape;
  };

  useEffect(() => {
    if (!mountRef.current) return;

    // --- SCENE SETUP ---
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x050505, 400, 1500);

    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 3000);
    camera.position.z = 950;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // --- LIGHTING ---
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.8);
    mainLight.position.set(500, 500, 800);
    scene.add(mainLight);

    const rimLight = new THREE.PointLight(0xffffff, 1.0);
    rimLight.position.set(-500, 0, -500);
    scene.add(rimLight);

    // --- SPHERE CREATION (COMPACT SYMMETRICAL RINGS) ---
    const sphereGroup = new THREE.Group();
    scene.add(sphereGroup);

    const radius = 360; // Reduced radius to minimize gaps
    const cardWidth = 140; // Slightly smaller cards for a denser look
    const cardHeight = 190;
    const cards: THREE.Mesh[] = [];
    const textureLoader = new THREE.TextureLoader();

    const roundedShape = createRoundedRectShape(cardWidth, cardHeight, 10);
    const geometry = new THREE.ShapeGeometry(roundedShape);

    /**
     * Tighter Latitude Distribution:
     * Pulling mid-rings closer to equator for a more solid 'ball' feel.
     */
    const rings = [
      { count: 1, phi: 0 },                  // Top Pole
      { count: 5, phi: Math.PI * 0.28 },     // Upper Mid (Tightened from 0.25)
      { count: 10, phi: Math.PI * 0.5 },      // Equator
      { count: 5, phi: Math.PI * 0.72 },     // Lower Mid (Tightened from 0.75)
      { count: 1, phi: Math.PI }             // Bottom Pole
    ];

    let cardIndex = 0;
    rings.forEach((ring) => {
      for (let i = 0; i < ring.count; i++) {
        if (cardIndex >= CARD_LIST.length) break;

        const item = CARD_LIST[cardIndex];
        const theta = (i / ring.count) * Math.PI * 2;

        const x = radius * Math.sin(ring.phi) * Math.cos(theta);
        const y = radius * Math.cos(ring.phi);
        const z = radius * Math.sin(ring.phi) * Math.sin(theta);

        const texture = textureLoader.load(item.imageUrl);
        texture.colorSpace = THREE.SRGBColorSpace;
        
        const material = new THREE.MeshStandardMaterial({
          map: texture,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0,
          roughness: 0.15,
          metalness: 0.2,
        });

        const card = new THREE.Mesh(geometry, material);
        card.position.set(x, y, z);
        
        // Face the center exactly
        card.lookAt(0, 0, 0);
        
        card.userData = { id: item.id };
        sphereGroup.add(card);
        cards.push(card);

        // Entry Fade
        setTimeout(() => {
          let opacity = 0;
          const fadeIn = () => {
            opacity += 0.05;
            material.opacity = Math.min(opacity, 1);
            if (opacity < 1) requestAnimationFrame(fadeIn);
          };
          fadeIn();
        }, cardIndex * 30);

        cardIndex++;
      }
    });

    // --- INTERACTION ---
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let hoveredCard: THREE.Mesh | null = null;
    let clickQuaternion = new THREE.Quaternion();
    let isRotatingToCard = false;

    const onMouseMove = (e: MouseEvent) => {
      mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    const onClick = () => {
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(cards);
      if (intersects.length > 0) {
        const clicked = intersects[0].object as THREE.Mesh;
        const targetDir = clicked.position.clone().normalize();
        const currentDir = new THREE.Vector3(0, 0, 1);
        const quaternion = new THREE.Quaternion().setFromUnitVectors(targetDir, currentDir);
        clickQuaternion.copy(quaternion);
        isRotatingToCard = true;
      }
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('click', onClick);

    // --- ANIMATION LOOP ---
    const animate = () => {
      // Scroll handling (Dynamic Depth)
      const scrollY = window.scrollY;
      const targetZ = 950 - (scrollY / 2000) * 1100;
      camera.position.z += (targetZ - camera.position.z) * 0.08;

      if (isRotatingToCard) {
        sphereGroup.quaternion.slerp(clickQuaternion, 0.08);
        if (sphereGroup.quaternion.angleTo(clickQuaternion) < 0.005) {
          isRotatingToCard = false;
        }
      } else {
        // Continuous rotation combined with slider offset
        const scrollerOffset = (rotationRef.current - 0.5) * Math.PI * 6; // Increased range
        targetRotationY.current = scrollerOffset;
        currentRotationY.current += (targetRotationY.current - currentRotationY.current) * 0.06;
        sphereGroup.rotation.y = currentRotationY.current + (performance.now() * 0.00015);
      }

      // Hover Effect
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(cards);
      
      if (hoveredCard) {
        hoveredCard.scale.lerp(new THREE.Vector3(1, 1, 1), 0.12);
        (hoveredCard.material as THREE.MeshStandardMaterial).emissive.setHex(0x000000);
      }

      if (intersects.length > 0) {
        hoveredCard = intersects[0].object as THREE.Mesh;
        hoveredCard.scale.lerp(new THREE.Vector3(1.18, 1.18, 1.18), 0.18);
        (hoveredCard.material as THREE.MeshStandardMaterial).emissive.setHex(0x444444);
      } else {
        hoveredCard = null;
      }

      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };

    const rafId = requestAnimationFrame(animate);

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('click', onClick);
      window.removeEventListener('resize', handleResize);
      mountRef.current?.removeChild(renderer.domElement);
    };
  }, []); 

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSliderVal(val);
    rotationRef.current = val;
  };

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <div ref={mountRef} className="fixed inset-0 z-0" />

      {/* Manual Rotation Scroller - Minimalist HUD */}
      <div className="fixed right-8 md:right-12 top-1/2 -translate-y-1/2 z-[100] flex flex-col items-center gap-10">
        <div className="text-[10px] uppercase tracking-[0.6em] text-white/10 rotate-90 mb-14 origin-center whitespace-nowrap pointer-events-none select-none font-semibold">
          SPATIAL CORE AXIS
        </div>
        
        <div className="relative h-80 w-10 flex items-center justify-center">
          {/* Visual Guides */}
          <div className="absolute h-full w-[1px] bg-white/5" />
          <div className="absolute h-[70%] w-[1px] bg-gradient-to-b from-transparent via-white/30 to-transparent" />
          
          {/* Functional range input - Standardized vertical style */}
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={sliderVal}
            onChange={handleSliderChange}
            className="absolute h-full w-full opacity-0 cursor-ns-resize z-20"
            style={{ 
              appearance: 'none',
              WebkitAppearance: 'none',
              writingMode: 'vertical-lr',
              direction: 'rtl'
            } as any}
          />

          {/* Precision Indicator (Handle) */}
          <div 
            className="absolute w-[2px] h-20 bg-white rounded-full shadow-[0_0_40px_rgba(255,255,255,0.6)] pointer-events-none transition-transform duration-300 ease-out"
            style={{ 
              bottom: `${sliderVal * 100}%`, 
              transform: `translateY(50%) scaleX(${1 + (sliderVal * 0.5)})`
            }}
          />
          
          {/* Notch indicators */}
          <div className="absolute -left-2 top-0 text-[8px] text-white/20 select-none">0°</div>
          <div className="absolute -left-2 top-1/2 -translate-y-1/2 text-[8px] text-white/20 select-none">180°</div>
          <div className="absolute -left-2 bottom-0 text-[8px] text-white/20 select-none">360°</div>
        </div>

        <div className="text-[11px] font-mono text-white/30 mt-10 tracking-widest tabular-nums bg-white/5 px-2 py-1 rounded backdrop-blur-sm border border-white/10">
          {Math.round(sliderVal * 360).toString().padStart(3, '0')}°
        </div>
      </div>
    </div>
  );
};

export default SphericalGallery;
