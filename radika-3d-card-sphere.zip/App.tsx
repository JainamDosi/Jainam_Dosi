
import React from 'react';
import SphericalGallery from './components/SphericalGallery';

function App() {
  return (
    <div className="relative min-h-[300vh] bg-[#050505] text-white selection:bg-white selection:text-black">
      <main className="fixed inset-0 w-full h-screen">
        <SphericalGallery />
      </main>
    </div>
  );
}

export default App;
