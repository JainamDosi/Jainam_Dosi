
export interface CardData {
  id: number;
  imageUrl: string;
  title: string;
  description: string;
}

export interface Position {
  x: number;
  y: number;
  z: number;
  rotateX: number;
  rotateY: number;
}
