
import { CardData } from './types';

export const CARD_LIST: CardData[] = [
  { id: 1, title: 'Running Reflection', description: 'City lights.', imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 2, title: 'Elegance Bold', description: 'Light study.', imageUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 3, title: 'Minimalist', description: 'Peak style.', imageUrl: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 4, title: 'Urban Solitude', description: 'Street stories.', imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 5, title: 'Chiaroscuro', description: 'Contrast.', imageUrl: 'https://images.unsplash.com/photo-1521119989659-a83eee488004?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 6, title: 'Vivid Reality', description: 'Future colors.', imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 7, title: 'Aged Grace', description: 'Generations.', imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 8, title: 'Mystic Gaze', description: 'Soul search.', imageUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 9, title: 'Silent Motion', description: 'Stillness.', imageUrl: 'https://images.unsplash.com/photo-1488161628813-04466f872be2?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 10, title: 'Soft Focus', description: 'Morning light.', imageUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 11, title: 'Architect', description: 'Structure.', imageUrl: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 12, title: 'Nordic Light', description: 'Cold tones.', imageUrl: 'https://images.unsplash.com/photo-1463453091185-61582044d556?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 13, title: 'Grit Grace', description: 'Texture.', imageUrl: 'https://images.unsplash.com/photo-1534030347209-467a5b0ad3e6?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 14, title: 'Golden Hour', description: 'Timeless.', imageUrl: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 15, title: 'Industrial', description: 'Aesthetics.', imageUrl: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 16, title: 'Dreamy', description: 'Softness.', imageUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 17, title: 'Modern Noir', description: 'Classic.', imageUrl: 'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 18, title: 'Natural Glow', description: 'Purity.', imageUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 19, title: 'Wanderlust', description: 'Travel.', imageUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 20, title: 'Cinematic', description: 'Stories.', imageUrl: 'https://images.unsplash.com/photo-1504257432389-52343af06ae3?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 21, title: 'Geometry', description: 'Abstract.', imageUrl: 'https://images.unsplash.com/photo-1513956589380-bad6acb9b9d4?auto=format&fit=crop&q=80&w=400&h=600' },
  { id: 22, title: 'Wild Heart', description: 'Untamed.', imageUrl: 'https://images.unsplash.com/photo-1514315384763-ba401779410f?auto=format&fit=crop&q=80&w=400&h=600' }
];

export const TOTAL_CARDS = CARD_LIST.length;
